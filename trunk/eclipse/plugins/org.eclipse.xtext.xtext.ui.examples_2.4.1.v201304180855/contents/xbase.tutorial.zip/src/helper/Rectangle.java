package helper;

public class Rectangle implements Shape {
	
	public int height, width;

	public Rectangle(int height, int width) {
		super();
		this.height = height;
		this.width = width;
	}
	
}
